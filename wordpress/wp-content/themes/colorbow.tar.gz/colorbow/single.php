<?php get_header(); ?>
<section id="main">

    <?php 
        get_template_part( 'single_content' ); 
    ?>  

</section>
<?php get_footer(); ?>
