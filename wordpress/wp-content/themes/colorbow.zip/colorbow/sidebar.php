<?php
    if(dynamic_sidebar( 'main' ) ){
        
    }
?>