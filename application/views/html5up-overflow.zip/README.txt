Overflow 1.1 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


This is Overflow, a single page responsive site template by me, AJ, for HTML5 UP.
As you can tell it's a bit unusual (it was inspired by a flowchart I was working
on a few months back), but I think it'd make for a pretty cool portfolio. Includes
a pop-up gallery, styling for all basic page elements, a handy configuration
(see the top of js/init.js), and some experimental stuff I've been messing with
lately (like the parallax background effect).
	
Demo images* courtesy of the talented, the awesome, THE one and only Felicia Simion,
a photographer whose works will make your head spin in awe. See more of it here:

http://ineedchemicalx.deviantart.com/

* Not included with this download (replaced with generic placeholder images), as
I only have permission to use her work in my own onsite demos. Do NOT download or
use any of her work without her explicit permission.


AJ
n33.co @n33co dribbble.com/n33


Credits

	Images (Demo Only)
		Felicia Simion (http://ineedchemicalx.deviantart.com/)
			"Sleepless in Vienna" (http://ineedchemicalx.deviantart.com/art/Sleepless-in-Vienna-322880007)
			"Time goes by too fast" (http://ineedchemicalx.deviantart.com/art/Time-goes-by-too-fast-335982438)
			"Kingdom of the Wind" (http://ineedchemicalx.deviantart.com/art/Kingdom-of-the-Wind-348268044)
			"Ad infinitum" (http://ineedchemicalx.deviantart.com/art/Ad-infinitum-354203162)
			"Dressed in Clarity" (http://ineedchemicalx.deviantart.com/art/Dressed-in-Clarity-331333716)
			"Raven" (http://ineedchemicalx.deviantart.com/art/Raven-306468505)
			"I'll have a cup of Disneyland, please" (http://ineedchemicalx.deviantart.com/art/I-ll-have-a-cup-of-Disneyland-please-325596442)
			"Cherish" (http://ineedchemicalx.deviantart.com/art/Cherish-320041163)
			"Different." (http://ineedchemicalx.deviantart.com/art/Different-353708988)
			"History was made here" (http://ineedchemicalx.deviantart.com/art/History-was-made-here-366723812)
			"People come and go and walk away" (http://ineedchemicalx.deviantart.com/art/People-come-and-go-and-walk-away-284244677)
			
		
	Icons
		Font Awesome (http://fortawesome.github.com/Font-Awesome/)

	Other
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		CSS3 PIE (http://css3pie.com/)
		background-size polyfill (https://github.com/louisremi/background-size-polyfill)
		jquery.poptrox (n33.co)
		skelJS (skeljs.org)